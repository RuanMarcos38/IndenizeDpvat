# Indenize DPVAT — Fluxo n8n com 3 Agentes de IA

Fluxo profissional de atendimento para a **Indenize Assessoria em Acidentes de Trânsito**, preparado para importar no n8n e integrar com WhatsApp/Evolution API, Supabase, OpenAI e rotina de follow-up.

## O que foi criado

- `n8n/indenize-atendimento-principal.json`  
  Workflow principal: recebe mensagem do WhatsApp, normaliza dados, consulta/cria lead, busca histórico, executa IA, salva mensagens, agenda quando necessário e responde pelo WhatsApp.

- `n8n/indenize-followup-semanal.json`  
  Workflow de follow-up: roda diariamente, identifica contatos sem retorno e envia abordagem consultiva. O intervalo semanal é controlado pelo campo `next_followup_at`.

- `supabase/schema.sql`  
  Banco de dados completo para contatos, mensagens, casos, agendamentos e controle de follow-up.

- `prompts/indenize-agentes.md`  
  Prompt mestre dos 3 agentes de IA.

- `knowledge-base/indenize-servicos.md`  
  Base de conhecimento com informações do site, regras de atendimento, documentos e serviços.

- `.env.example`  
  Variáveis obrigatórias para configurar o n8n.

- `docs/arquitetura-fluxo.md`  
  Explicação técnica do funcionamento.

## Agentes de IA

1. **Agente 01 — Recepção e Triagem**  
   Acolhe, entende o acidente e identifica o serviço correto.

2. **Agente 02 — Especialista em Indenizações e Documentos**  
   Explica DPVAT, invalidez, óbito, seguro de vida, seguro de terceiros/RCF, auxílio-acidente e documentos necessários.

3. **Agente 03 — Agendamento e Follow-up**  
   Agenda visita presencial ou call, respeitando horário comercial e reativa clientes semanalmente.

## Horário de atendimento

Conforme site da Indenize:

- Segunda a sexta
- 08h às 12h
- 13h às 18h
- Visita presencial somente em horário comercial

## Como importar no n8n

1. Acesse o n8n.
2. Vá em **Workflows**.
3. Clique em **Import from file**.
4. Importe primeiro:
   - `n8n/indenize-atendimento-principal.json`
5. Depois importe:
   - `n8n/indenize-followup-semanal.json`
6. Configure as variáveis do ambiente conforme `.env.example`.
7. Crie as tabelas no Supabase com `supabase/schema.sql`.
8. Configure o webhook da Evolution API para apontar para:
   - `/webhook/indenize/whatsapp/inbound`

## Variáveis obrigatórias

Veja o arquivo `.env.example`.

Principais:

- `OPENAI_API_KEY`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `EVOLUTION_API_URL`
- `EVOLUTION_API_KEY`
- `EVOLUTION_INSTANCE`
- `INDENIZE_TIMEZONE=America/Sao_Paulo`

## Observação importante

O agente não promete aprovação de indenização, valor final, prazo de pagamento ou resultado jurídico.  
Ele orienta, qualifica, coleta informações e agenda análise com especialista.

## Estrutura recomendada no n8n

- Workflow principal ativo 24h.
- Workflow de follow-up ativo em dias úteis.
- Supabase como memória e CRM.
- Evolution API como canal de WhatsApp.
- OpenAI como motor dos agentes.
