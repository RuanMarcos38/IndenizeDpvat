# Arquitetura Técnica — Fluxo Indenize DPVAT no n8n

## Visão geral

O projeto foi desenhado para atendimento profissional via WhatsApp usando Evolution API, memória em Supabase e IA com OpenAI.

## Workflow 1 — Atendimento principal

Entrada:
- Webhook da Evolution API.

Processamento:
1. Normaliza mensagem recebida.
2. Ignora mensagens inválidas, grupos, mensagens próprias e textos vazios.
3. Busca contato no Supabase.
4. Cria ou atualiza contato.
5. Salva mensagem recebida.
6. Busca histórico recente.
7. Monta contexto com base de conhecimento.
8. Executa agente de IA.
9. Valida agenda quando houver pedido de visita/call.
10. Salva agendamento se estiver dentro do horário permitido.
11. Envia resposta pelo WhatsApp.
12. Salva resposta enviada.
13. Atualiza estágio e próximo follow-up.

## Workflow 2 — Follow-up semanal

Entrada:
- Schedule Trigger diário às 09h.

Processamento:
1. Busca contatos com `next_followup_at <= now()`.
2. Monta mensagem de follow-up com IA.
3. Envia WhatsApp.
4. Salva histórico.
5. Atualiza `followup_count` e agenda novo follow-up semanal.

## Memória

A memória fica no Supabase:
- `indenize_contacts`
- `indenize_messages`
- `indenize_cases`
- `indenize_appointments`
- `indenize_followups`
- `indenize_kb_sources`

## Regras de segurança

- A chave Service Role deve ficar somente no servidor/n8n.
- Não expor Service Role no frontend.
- O agente não promete direito, valor ou aprovação.
- O agente usa fallback para humano quando houver dúvida crítica.

## Personalização recomendada

Depois de importar:
1. Configure credenciais/variáveis.
2. Ative o webhook na Evolution API.
3. Teste com 3 casos:
   - DPVAT/invalidez
   - Óbito
   - Agendamento de visita
4. Ajuste telefone do handoff humano.
5. Configure horário de call se for diferente do escritório.
