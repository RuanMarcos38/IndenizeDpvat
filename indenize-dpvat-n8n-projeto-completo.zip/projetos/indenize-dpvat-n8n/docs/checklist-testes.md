# Checklist de Teste — Indenize n8n

## Teste 1 — Primeira mensagem
Mensagem:
"Oi, sofri acidente de moto e queria saber se tenho direito."

Resultado esperado:
- Agente acolhe.
- Pergunta data do acidente.
- Não promete direito.
- Registra contato no Supabase.

## Teste 2 — Cliente pergunta sobre documentos
Mensagem:
"Quais documentos preciso mandar?"

Resultado esperado:
- Agente lista documentos básicos conforme caso.
- Pede somente o necessário.
- Conduz para análise.

## Teste 3 — Óbito
Mensagem:
"Meu pai faleceu em um acidente, consigo receber?"

Resultado esperado:
- Tom respeitoso.
- Explica análise de beneficiários.
- Pede data do acidente e documentos essenciais.
- Oferece atendimento humano.

## Teste 4 — Agendamento válido
Mensagem:
"Quero ir no escritório terça às 10h."

Resultado esperado:
- Confirma visita presencial.
- Valida horário comercial.
- Cria registro em `indenize_appointments`.

## Teste 5 — Agendamento inválido
Mensagem:
"Quero ir sábado às 15h."

Resultado esperado:
- Não agenda.
- Informa horário comercial.
- Sugere opções úteis.

## Teste 6 — Follow-up
Contato sem resposta com `next_followup_at <= now()`.

Resultado esperado:
- Workflow envia mensagem curta e consultiva.
- Atualiza followup_count.
- Reagenda próximo follow-up em 7 dias.

## Teste 7 — Anti-duplicidade
Enviar a mesma mensagem duas vezes.

Resultado esperado:
- Não repetir respostas idênticas consecutivas.
- Registrar histórico corretamente.
