# Base de Conhecimento — Indenize Assessoria em Acidentes de Trânsito

> Projeto: fluxo n8n com 3 agentes de IA para atendimento, qualificação, documentação, agendamento e follow-up.

## 1. Dados oficiais extraídos do site da Indenize

- Site: https://indenizedpvat.com.br/
- Telefone: (47) 3804-4080
- WhatsApp: +55 (47) 9 9669-0907
- E-mail: atendimento@indenizedpvat.com.br
- Endereço: Rua Dona Francisca, 537 - Centro, Joinville/SC - Brasil
- Horário informado no site: segunda a sexta, 08h às 12h e 13h às 18h.
- Posicionamento: especialista em benefícios e indenizações.
- A empresa se apresenta como especializada em indenizações que amparam vítimas de acidentes de qualquer natureza.
- Serviços citados no site: DPVAT, invalidez, óbito, seguro de terceiros/RCF, seguro de vida, auxílio-acidente/INSS, entre outros.
- O site informa atuação em acidentes de trânsito, domésticos, esportivos ou de trabalho, conforme coberturas previstas em apólices e análise do caso.

## 2. Informações de DPVAT usadas como base segura

As regras de DPVAT/SPVAT mudaram nos últimos anos. Por isso o agente deve:
- Não prometer que todo acidente atual terá pagamento imediato.
- Sempre validar a data do acidente.
- Informar que a análise documental é necessária.
- Direcionar casos sensíveis para especialista humano.

Base operacional do site da Indenize:
- DPVAT é apresentado como direito previsto na Lei Federal 6.194/74.
- Indenizações citadas: despesas médicas/suplementares, invalidez permanente e morte.
- Valores históricos citados no site:
  - DAMS/despesas médicas e suplementares: até R$ 2.700,00 mediante comprovação.
  - Invalidez permanente: até R$ 13.500,00 conforme avaliação.
  - Morte: até R$ 13.500,00 aos beneficiários legais.
- Prazos citados no site:
  - DAMS e invalidez: até 3 anos contados da data do acidente ou da ciência da invalidez.
  - Morte: até 3 anos a partir do óbito.

Regra de fala segura:
"Como as regras do DPVAT/SPVAT tiveram mudanças, o ideal é analisar a data do acidente e os documentos. Eu consigo te orientar agora e também agendar uma análise com especialista da Indenize."

## 3. Serviços e explicação simples

### DPVAT / acidente de trânsito
Para vítimas de acidente de trânsito, incluindo motorista, passageiro, pedestre, ciclista ou motociclista, dependendo da data do acidente, documentos e enquadramento.

### Invalidez permanente
Quando o acidente deixou sequela ou limitação permanente. O agente deve perguntar se existem laudos, exames, relatório médico e se já houve perícia.

### Óbito
Atendimento a familiares/beneficiários legais. O tom deve ser acolhedor. Solicitar, com cuidado, certidão de óbito, documentos da vítima, documentos dos beneficiários e registros do acidente.

### Despesas médicas
Reembolso quando cabível, mediante notas, recibos, comprovantes, relatórios e vínculo com o acidente.

### Seguro de terceiros / RCF
Pode envolver apólice de seguro, responsabilidade civil facultativa ou cobertura contratada. Solicitar dados do acidente, seguradora, apólice, negativa ou comunicação do sinistro.

### Seguro de vida
Verificar se havia apólice, cobertura por acidente, morte, invalidez ou diárias. Solicitar apólice, certificado, proposta, negativa e documentos médicos.

### Auxílio-acidente / INSS
Pode ser avaliado quando há sequela que reduza capacidade de trabalho. O agente deve pedir profissão, afastamento, laudos e se houve perícia ou benefício anterior.

## 4. Documentos por situação

### Documentos básicos
- RG ou CNH
- CPF
- Comprovante de residência
- Telefone e e-mail
- Dados bancários quando solicitado pelo especialista

### Acidente de trânsito
- Boletim de ocorrência
- Prontuário ou relatório médico
- Exames e laudos
- Fotos, se houver
- Comprovantes de despesas médicas
- Documentos do veículo, se necessário

### Invalidez / sequelas
- Laudos médicos
- Exames de imagem
- Relatório de cirurgia ou internação
- Atestados
- CAT, se acidente de trabalho
- Documentos de afastamento/INSS, se houver

### Óbito
- Certidão de óbito
- Documentos da vítima
- Documentos dos beneficiários legais
- Certidão de casamento/união estável/nascimento conforme o caso
- Boletim de ocorrência
- Documentos médicos e registros do acidente

## 5. Regras comerciais e de atendimento

- Nunca falar como se fosse garantia de ganho.
- Vender confiança, clareza e análise.
- Reforçar que a Indenize possui atendimento físico em Joinville.
- O objetivo é levar o cliente para análise de especialista.
- Quando o cliente perguntar valor/honorário: "A política de honorários é explicada com transparência depois que entendermos o tipo de caso e os documentos disponíveis."
- Quando o cliente estiver inseguro: reforçar endereço, telefone, atendimento humano e análise responsável.

## 6. Horário de atendimento

- Escritório/visita presencial: segunda a sexta, 08h às 12h e 13h às 18h.
- Fora do horário: coletar dados, acolher, informar que o time retornará no próximo horário útil e oferecer agendamento.
- Calls: seguir a mesma regra, salvo configuração interna diferente.

## 7. Agentes

### Agente 01 — Triagem
Acolhe, identifica caso e coleta dados iniciais.

### Agente 02 — Especialista
Explica indenizações, documentos e possibilidades de análise.

### Agente 03 — Agenda/Follow-up
Agenda visita/call, confirma e reativa clientes.

## 8. Frases prontas aprovadas

- "Entendi sua situação. Vamos analisar com cuidado para verificar o melhor caminho."
- "Para te orientar com segurança, preciso confirmar a data do acidente."
- "Você prefere conversar por call ou fazer uma visita presencial no escritório?"
- "A visita presencial acontece em horário comercial, de segunda a sexta, das 8h às 12h e das 13h às 18h."
- "Não vou te prometer algo sem análise, mas consigo te orientar e encaminhar para uma avaliação correta."
