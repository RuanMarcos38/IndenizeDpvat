-- Indenize DPVAT — Schema Supabase para n8n
-- Execute no SQL Editor do Supabase.

create extension if not exists pgcrypto;

create table if not exists public.indenize_contacts (
  id uuid primary key default gen_random_uuid(),
  phone text not null unique,
  name text,
  email text,
  city text,
  state text,
  origin text default 'whatsapp',
  status text not null default 'novo',
  stage text not null default 'novo',
  service_interest text,
  accident_type text,
  accident_date date,
  urgency text default 'media',
  last_inbound_at timestamptz,
  last_outbound_at timestamptz,
  last_message text,
  next_followup_at timestamptz,
  followup_count integer not null default 0,
  assigned_to text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.indenize_messages (
  id uuid primary key default gen_random_uuid(),
  contact_phone text not null references public.indenize_contacts(phone) on delete cascade,
  direction text not null check (direction in ('inbound','outbound','internal')),
  channel text not null default 'whatsapp',
  message_id text,
  agent_used text,
  body text not null,
  raw_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.indenize_cases (
  id uuid primary key default gen_random_uuid(),
  contact_phone text not null references public.indenize_contacts(phone) on delete cascade,
  case_type text,
  accident_date date,
  accident_city text,
  accident_state text,
  victim_name text,
  requester_relation text,
  has_death boolean,
  has_injury boolean,
  has_disability boolean,
  has_medical_expenses boolean,
  has_police_report boolean,
  documents_status text not null default 'pendente',
  notes text,
  status text not null default 'em_qualificacao',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.indenize_appointments (
  id uuid primary key default gen_random_uuid(),
  contact_phone text not null references public.indenize_contacts(phone) on delete cascade,
  type text not null check (type in ('visita','call')),
  scheduled_at timestamptz not null,
  timezone text not null default 'America/Sao_Paulo',
  status text not null default 'agendado',
  subject text,
  notes text,
  created_by text default 'ia',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.indenize_followups (
  id uuid primary key default gen_random_uuid(),
  contact_phone text not null references public.indenize_contacts(phone) on delete cascade,
  scheduled_at timestamptz not null,
  sent_at timestamptz,
  status text not null default 'pendente',
  reason text,
  message text,
  created_at timestamptz not null default now()
);

create table if not exists public.indenize_kb_sources (
  id uuid primary key default gen_random_uuid(),
  source_name text not null,
  source_url text,
  content text not null,
  source_type text default 'manual',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_indenize_messages_phone_created on public.indenize_messages(contact_phone, created_at desc);
create index if not exists idx_indenize_contacts_followup on public.indenize_contacts(next_followup_at, status);
create index if not exists idx_indenize_appointments_scheduled on public.indenize_appointments(scheduled_at, status);

create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_indenize_contacts_updated on public.indenize_contacts;
create trigger trg_indenize_contacts_updated
before update on public.indenize_contacts
for each row execute function public.set_updated_at();

drop trigger if exists trg_indenize_cases_updated on public.indenize_cases;
create trigger trg_indenize_cases_updated
before update on public.indenize_cases
for each row execute function public.set_updated_at();

drop trigger if exists trg_indenize_appointments_updated on public.indenize_appointments;
create trigger trg_indenize_appointments_updated
before update on public.indenize_appointments
for each row execute function public.set_updated_at();

-- RLS opcional: o n8n deve usar Service Role Key no backend/servidor.
alter table public.indenize_contacts enable row level security;
alter table public.indenize_messages enable row level security;
alter table public.indenize_cases enable row level security;
alter table public.indenize_appointments enable row level security;
alter table public.indenize_followups enable row level security;
alter table public.indenize_kb_sources enable row level security;

-- Seed inicial da base de conhecimento.
insert into public.indenize_kb_sources (source_name, source_url, content, source_type)
values
('Site oficial Indenize', 'https://indenizedpvat.com.br/', 'Indenize Assessoria é especializada em indenizações que amparam vítimas de acidentes de qualquer natureza. Serviços citados: DPVAT, invalidez, óbito, seguro de terceiros/RCF, seguro de vida, auxílio-acidente/INSS, entre outros. Endereço: Rua Dona Francisca, 537 - Centro, Joinville/SC. Horário: segunda a sexta, 08h às 12h e 13h às 18h.', 'site'),
('Regras operacionais atendimento IA', null, 'Atendimento humano, consultivo, sem promessa de resultado. Qualificar caso, solicitar documentos conforme necessidade e agendar visita ou call com especialista.', 'manual')
on conflict do nothing;
